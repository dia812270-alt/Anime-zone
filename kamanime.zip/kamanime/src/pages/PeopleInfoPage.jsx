import React from "react";

const PeopleInfoPage = () => {
  return (
    <div className="h-screen flex justify-center items-center">
      <h1>not implemented</h1>
    </div>
  );
};

export default PeopleInfoPage;
