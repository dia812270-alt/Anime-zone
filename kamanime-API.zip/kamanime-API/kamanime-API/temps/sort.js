const arrOfObj = [
  {
    id: 1,
    genre: 'action',
  },
  {
    id: 2,
    genre: 'adventure',
  },
  {
    id: 3,
    genre: 'cars',
  },
  {
    id: 4,
    genre: 'comedy',
  },
  {
    id: 5,
    genre: 'dementia',
  },
  {
    id: 6,
    genre: 'demons',
  },
  {
    id: 7,
    genre: 'mystery',
  },
  {
    id: 8,
    genre: 'drama',
  },
  {
    id: 9,
    genre: 'ecchi',
  },
  {
    id: 10,
    genre: 'fantasy',
  },
  {
    id: 11,
    genre: 'game',
  },
  {
    id: 13,
    genre: 'historical',
  },
  {
    id: 14,
    genre: 'horror',
  },
  {
    id: 15,
    genre: 'kids',
  },
  {
    id: 16,
    genre: 'magic',
  },
  {
    id: 17,
    genre: 'martial_arts',
  },
  {
    id: 18,
    genre: 'mecha',
  },
  {
    id: 19,
    genre: 'music',
  },
  {
    id: 20,
    genre: 'parody',
  },
  {
    id: 21,
    genre: 'samurai',
  },
  {
    id: 22,
    genre: 'romance',
  },
  {
    id: 23,
    genre: 'school',
  },
  {
    id: 24,
    genre: 'sci-fi',
  },
  {
    id: 25,
    genre: 'shoujo',
  },
  {
    id: 26,
    genre: 'shoujo_ai',
  },
  {
    id: 27,
    genre: 'shounen',
  },
  {
    id: 28,
    genre: 'shounen_ai',
  },
  {
    id: 29,
    genre: 'space',
  },
  {
    id: 30,
    genre: 'sports',
  },
  {
    id: 31,
    genre: 'super_power',
  },
  {
    id: 32,
    genre: 'vampire',
  },
  {
    id: 35,
    genre: 'harem',
  },
  {
    id: 36,
    genre: 'slice_of_life',
  },
  {
    id: 37,
    genre: 'supernatural',
  },
  {
    id: 38,
    genre: 'military',
  },
  {
    id: 39,
    genre: 'police',
  },
  {
    id: 40,
    genre: 'psychological',
  },
  {
    id: 41,
    genre: 'thriller',
  },
  {
    id: 42,
    genre: 'seinen',
  },
  {
    id: 43,
    genre: 'josei',
  },
  {
    id: 44,
    genre: 'isekai',
  },
];

console.log(arrOfObj);
